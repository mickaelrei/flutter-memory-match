package com.example.desafio_academy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
