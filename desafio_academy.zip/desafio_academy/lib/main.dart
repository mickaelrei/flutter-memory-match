import 'package:desafio_academy/game_state.dart';
import 'package:desafio_academy/score_state.dart';
import 'package:flutter/material.dart';
import 'package:desafio_academy/game_page.dart';
import 'package:desafio_academy/menu_page.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jogo da memória',
      debugShowCheckedModeBanner: false,
      initialRoute: "/",
      routes: {
        "/": (context) => const MenuPage(),
        "/game": (context) => const GamePage(),
      },
    );
  }
}
