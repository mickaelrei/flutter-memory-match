import 'package:desafio_academy/game_state.dart';
import 'package:desafio_academy/score_state.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MenuPage extends StatelessWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ScoreState(),
      child: Consumer<ScoreState>(builder: (_, state, __) {
        return Scaffold(
          appBar: AppBar(title: const Text("Menu")),
          body: Column(
            children: [
              Align(
                alignment: Alignment.topCenter,
                child: Text("Pontuação máxima: ${state.highscore}"),
              ),
              Center(
                child: const Text(
                  "Jogo da memória",
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),
              IconButton(
                onPressed: () async {
                  // Entra na rota de jogo e espera retorno da pontuação
                  final score =
                      await Navigator.of(context).pushNamed("/game") as int;

                  // Cadastra nova pontuação
                  state.newScore(score);
                },
                icon: const Icon(Icons.play_arrow),
                color: Colors.green,
                iconSize: 40,
              )
            ],
          ),
        );
      }),
    );
  }
}
