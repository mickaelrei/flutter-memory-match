import 'dart:math';
import 'package:desafio_academy/game_state.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class GamePage extends StatelessWidget {
  const GamePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => GameState(context: context, numPairs: 6),
      child: Consumer<GameState>(
        builder: (context, gameState, child) {
          return Scaffold(
            appBar: AppBar(title: const Text("Jogo da memória")),
            body: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 30,
                crossAxisSpacing: 30,
              ),
              padding: const EdgeInsets.all(150.0),
              itemCount: gameState.numPairs * 2,
              itemBuilder: (context, index) => gameState.CardAt(index),
            ),
          );
        },
      ),
    );
  }
}
