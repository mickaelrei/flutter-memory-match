import 'package:flutter/material.dart';

class ScoreState with ChangeNotifier {
  ScoreState();

  // Pontuação máxima atual
  int _highscore = 0;
  int get highscore => _highscore;

  // Lista de pontuações
  final scores = <int>[];

  // Função pra cadastrar nova pontuação
  void newScore(int score) {
    // Adiciona na lista de tentativas
    scores.add(score);

    // Atualiza pontuação máxima caso necessário
    if (score > _highscore) {
      _highscore = score;
    }

    // Atualiza tela
    notifyListeners();
  }
}